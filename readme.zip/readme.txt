ArduinoSource исходный код прошивки
LedCubeProteus полная модель всего проекта с одним слоем(тормозит звук при запуске симуляции)
SoundTest модель только с динамиком, для тестирования звука

После первого запуска проекта необходимо выбрать прошивку для микроконтроллера.

Используется Proteus 8 Professional 8.8 SP1 (Build 27031) with Advanced Simulation

Скачать можно:
https://prog-top.net/raznoe/8038-proektirovanie-elektronnyh-shem-proteus-8-professional-88-sp1-build-27031-with-advanced-simulation.html